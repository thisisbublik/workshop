# CI-workshop
Demo setup of CI using GitHub, Travis CI, Heroku and Sauce Labs
